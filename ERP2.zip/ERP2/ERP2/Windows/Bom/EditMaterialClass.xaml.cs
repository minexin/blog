﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP2.Windows.Bom
{
    /// <summary>
    /// EditMaterialClass.xaml 的交互逻辑
    /// </summary>
    public partial class EditMaterialClass : Window
    {
        private int index;
        public EditMaterialClass(int index)
        {
            InitializeComponent();
            cbClass.ItemsSource = RawMaterialClass.GetClassesExcept(index);
            this.index = index;
            var temp = RawMaterialClass.GetById(index);
            cbClass.SelectedValue = temp.ParentId;
            txtName.Text = temp.Name;
        }

        private void btnOK(object sender, RoutedEventArgs e)
        {
            using (var db = new Entities())
            {
                var temp = db.RawMaterialClassSet.First(i => i.Id == index);
                temp.Name = txtName.Text;
                temp.ParentId = (int?)cbClass.SelectedValue;
                db.SaveChanges();
                DialogResult = true;
                Close();
            }
        }
    }
}
