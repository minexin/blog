﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP2.Windows.Bom
{
    /// <summary>
    /// NewProduct.xaml 的交互逻辑
    /// </summary>
    public partial class NewProduct : Window
    {
        private List<ProductFormulaView> formula;
        private bool isNew = true;
        private int id;

        public NewProduct(int? index)
        {
            InitializeComponent();
            Title = "新建产品配方";
            cbClass.ItemsSource = ProductClass.GetAllClasses(false);
            cbClass.SelectedValue = index;
            formula = new List<ProductFormulaView>();
            dgMaterialItems.ItemsSource = formula;
        }

        //传入一个Product对象, 修改产品配方
        public NewProduct(Product product)
        {
            InitializeComponent();
            Title = "修改产品配方";
            cbClass.ItemsSource = ProductClass.GetAllClasses(false);
            cbClass.SelectedValue = product.ClassId;
            txtCode.Text = product.Code;
            txtName.Text = product.Name;
            txtPrice.Text = product.Price.ToString();
            txtSpecification.Text = product.ProductModel;
            txtInventor.Text = product.Inventor;
            txtPatentNo.Text = product.PatentNo;
            txtDescription.Text = product.Description;
            formula = ProductFormulaView.GetByProductId(product.Id);
            dgMaterialItems.ItemsSource = formula;
            isNew = false;
            id = product.Id;
        }

        private void BtnNewItem(object sender, RoutedEventArgs e)
        {
            var nWin = new NewFormulaItem();
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                var index = formula.FindIndex(x => x.Id == Global.tempProductFormulaView.Id);
                if (index == -1)
                    formula.Add(Global.tempProductFormulaView);
                else
                    formula[index].Quantity += Global.tempProductFormulaView.Quantity;
                Global.tempProductFormulaView = null;
                dgMaterialItems.Items.Refresh();
            }
        }

        private void BtnEditItem(object sender, RoutedEventArgs e)
        {
            var temp = dgMaterialItems.SelectedItem as ProductFormulaView;
            var nWin = new NewFormulaItem(temp);
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                var index = formula.FindIndex(x => x.Id == Global.tempProductFormulaView.Id);
                formula[index] = Global.tempProductFormulaView;
                Global.tempProductFormulaView = null;
                dgMaterialItems.Items.Refresh();
            }
        }

        private void BtnDeleteItem(object sender, RoutedEventArgs e)
        {
            var temp = dgMaterialItems.SelectedItem as ProductFormulaView;
            formula.Remove(temp);
            dgMaterialItems.Items.Refresh();
        }

        private void BtnOK(object sender, RoutedEventArgs e)
        {
            double temp;
            if (cbClass.SelectedValue == null)
                message.Text = "请选择产品种类!";
            else if (txtCode.Text == "")
                message.Text = "请输入产品编号!";
            else if (txtName.Text == "")
                message.Text = "请输入产品名称!";
            else if (txtPrice.Text == "")
                message.Text = "请输入产品价格!";
            else if (!double.TryParse(txtPrice.Text, out temp))
                message.Text = "请输入正确的产品价格!";
            else if (formula.Count == 0)
                message.Text = "请添加至少一个配方条目!";
            else {
                using (var db = new Entities())
                {
                    if (isNew)
                    {
                        var product = new Product();
                        product.Code = txtCode.Text;
                        product.Name = txtName.Text;
                        product.Price = double.Parse(txtPrice.Text);
                        product.ProductModel = txtSpecification.Text;
                        product.Inventor = txtInventor.Text;
                        product.PatentNo = txtPatentNo.Text;
                        product.Description = txtDescription.Text;
                        product.ClassId = (int)cbClass.SelectedValue;
                        product.AddTime = DateTime.Now;
                        db.ProductSet.Add(product);
                        db.SaveChangesAsync();
                        var storageProduct = db.ProductSet.First(i => i.Code == product.Code && i.Name == product.Name);
                        id = storageProduct.Id;
                    }
                    else
                    {
                        var toDelete = db.ProductFormulaItemSet.Where(i => i.ProductId == id).ToList();
                        db.ProductFormulaItemSet.RemoveRange(toDelete);
                        db.SaveChanges();
                    }
                    foreach (var i in formula)
                    {
                        var formulaItem = new ProductFormulaItem();
                        formulaItem.ProductId = id;
                        formulaItem.RawMaterialId = i.Id;
                        formulaItem.Quantity = i.Quantity;
                        db.ProductFormulaItemSet.Add(formulaItem);
                    }
                    db.SaveChanges();
                    DialogResult = true;
                    Close();
                }
            }
        }

        private void BtnCancel(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ChangeBtnEnabled(object sender, SelectedCellsChangedEventArgs e)
        {
            if(dgMaterialItems.SelectedItem == null)
            {
                btnEditItem.IsEnabled = false;
                btnDeleteItem.IsEnabled = false;
            }
            else
            {
                btnEditItem.IsEnabled = true;
                btnDeleteItem.IsEnabled = true;
            }
        }
    }
}
