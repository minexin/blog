﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP2.Windows.Bom
{
    /// <summary>
    /// NewProductClass.xaml 的交互逻辑
    /// </summary>
    public partial class NewProductClass : Window
    {
        public NewProductClass(List<ProductClass> list, int? index)
        {
            //TODO: 添加可以选择类别为根类的项目
            InitializeComponent();
            cbClass.ItemsSource = list;
            cbClass.SelectedValue = index;
        }

        private void btnOK(object sender, RoutedEventArgs e)
        {
            using (var db = new Entities())
            {
                var temp = new ProductClass();
                temp.Name = txtName.Text;
                temp.ParentId = (int?)cbClass.SelectedValue;
                db.ProductClassSet.Add(temp);
                db.SaveChanges();
                DialogResult = true;
                Close();
            }
        }
    }
}
