﻿using System.Windows.Controls;
using System.Collections.Generic;
using System.Linq;

namespace ERP2
{
    public partial class ProductClass
    {
        public TreeViewItem GetTreeViewItem()
        {
            var tvi = new TreeViewItem();
            tvi.Header = Name;
            tvi.DataContext = Id;
            tvi.IsExpanded = true;
            foreach (var i in ChildClass)
            {
                tvi.Items.Add(i.GetTreeViewItem());
            }
            return tvi;
        }

        public static List<ProductClass> GetAllClasses(bool containRoot)
        {
            using (var db = new Entities())
            {
                if (containRoot)
                {
                    var classes = new List<ProductClass>();
                    var root = new ProductClass();
                    root.Name = "- 根分类 -";
                    root.ParentId = null;
                    classes.Add(root);
                    var temp = db.ProductClassSet.Select(i => i).ToList();
                    classes = classes.Concat(temp).ToList();
                    return classes;
                }
                else
                    return db.ProductClassSet.Select(i => i).ToList();
            }
        }

        public static List<ProductClass> GetClassesExcept(int index)
        {
            using (var db = new Entities())
            {
                var classes = new List<ProductClass>();
                var root = new ProductClass();
                root.Name = "- 根分类 -";
                root.ParentId = null;
                classes.Add(root);
                var temp = db.ProductClassSet.Where(i => i.Id != index).Select(i => i).ToList();
                classes = classes.Concat(temp).ToList();
                return classes;
            }
        }

        public static List<ProductClass> GetClassesExceptSub(int index)
        {
            var list = GetAllClasses(true);
            var sub = GetSubClassIndexs(index);
            var classes = new List<ProductClass>();
            foreach (var i in list)
            {
                if (sub.FindIndex(x => x == i.Id) == -1)
                {
                    classes.Add(i);
                }
            }
            return classes;
        }

        public static ProductClass GetById(int index)
        {
            using (var db = new Entities())
            {
                return db.ProductClassSet.First(i => i.Id == index);
            }
        }

        public static List<int> GetSubClassIndexs(int index)
        {
            using (var db = new Entities())
            {
                var dSubIndexs = db.ProductClassSet.Where(i => i.ParentId == index).Select(i => i.Id).ToList();
                var sumIndexs = new List<int>(dSubIndexs);
                sumIndexs.Add(index);

                foreach (var subIndex in dSubIndexs)
                {
                    var tempList = GetSubClassIndexs(subIndex);
                    sumIndexs = sumIndexs.Union(tempList).ToList();
                }
                return sumIndexs;
            }
        }

        public static List<Product> GetSubClassProducts(int index)
        {
            var classList = GetSubClassIndexs(index);
            using (var db = new Entities())
            {
                var sumList = new List<Product>();
                foreach (int id in classList)
                {
                    var temp = db.ProductSet.Where(i => i.ClassId == id).Select(i => i).ToList();
                    sumList = sumList.Union(temp).ToList();
                }
                return sumList;
            }
        }

        public static void DeleteSubClass(int index)
        {
            //TODO: 实现级联删除
            using (var db = new Entities())
            {
                var temp = db.ProductClassSet.First(i => i.Id == index);
                db.ProductClassSet.Remove(temp);
                db.SaveChanges();
            }
        }
    }
}
