use erp;


/*
insert into usergroupset values(0, "房东", 1);
insert into usergroupset values(0, "房客", 2);

insert into rawmaterialclassset values(0, "建筑材料", null);
insert into rawmaterialclassset values(0, "工具配件", null);
insert into rawmaterialclassset values(0, "矿物", null);
insert into rawmaterialclassset values(0, "石质材料", 1);
insert into rawmaterialclassset values(0, "木质材料", 1);

insert into rawmaterialset values(0, "圆石", "1立方米", "个", 4, true);
insert into rawmaterialset values(0, "石头", "1立方米", "个", 4, true);
insert into rawmaterialset values(0, "橡木原木", "1立方米", "个", 5, true);
insert into rawmaterialset values(0, "橡木", "1立方米", "个", 5, true);
insert into rawmaterialset values(0, "木棍", "1m*5cm*5cm", "个", 2, true);
insert into rawmaterialset values(0, "煤炭", "1kg", "个", 3, true);

insert into productclassset values(0, "工具", null);

insert into productset values(0, "A0001", "工作台", 1.00, "标准型", "史蒂夫", "A0001", "2000-01-01 00:00:00", "必备的工具", 1, true);
insert into productformulaitemset values(0, 4, 4, 1);*/

insert into userset values(0, "A0001", "admin", "password", 1);

select * from rawmaterialset;