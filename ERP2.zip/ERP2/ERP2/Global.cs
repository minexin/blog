﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP2
{
    class Global
    {
        public static User user;
        public static Windows.MainWindow MainWindow;
        public static ProductFormulaView tempProductFormulaView;
    }
}
