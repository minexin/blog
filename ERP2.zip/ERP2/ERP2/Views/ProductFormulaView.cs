﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP2
{
    public class ProductFormulaView
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public string Specification { get; set; }
        public string Unit { get; set; }
        public int ProductId { get; set; }

        public static List<ProductFormulaView> GetByProductId(int index)
        {
            using (var db = new Entities())
            {
                string sql = string.Format("select * from productformulaview where ProductId={0}", index);
                return db.Database.SqlQuery<ProductFormulaView>(sql).ToList();
            }
        }
    }
}
