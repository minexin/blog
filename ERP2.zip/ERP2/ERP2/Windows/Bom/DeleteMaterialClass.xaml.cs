﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP2.Windows.Bom
{
    /// <summary>
    /// DeleteMaterialClass.xaml 的交互逻辑
    /// </summary>
    public partial class DeleteMaterialClass : Window
    {
        private int index;

        public DeleteMaterialClass(int index)
        {
            InitializeComponent();
            this.index = index;

            var classes = RawMaterialClass.GetClassesExceptSub(index);
            cbTransferTo.ItemsSource = classes;
        }

        public void BtnOK(object sender, RoutedEventArgs e)
        {
            if (ckbDeleteSubClass.IsChecked == true)
            {
                //TODO: 将某类下零件全部转移到另一个类
            }
            RawMaterialClass.DeleteSubClass(index);
            DialogResult = true;
            Close();
        }

    }
}
