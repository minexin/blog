﻿using System.Windows.Controls;
using System.Collections.Generic;
using System.Linq;

namespace ERP2
{
    public partial class RawMaterialClass
    {
        public TreeViewItem GetTreeViewItem()
        {
            var tvi = new TreeViewItem();
            tvi.Header = Name;
            tvi.DataContext = Id;
            tvi.IsExpanded = true;
            foreach (var i in ChildClass)
            {
                tvi.Items.Add(i.GetTreeViewItem());
            }
            return tvi;
        }

        public static List<RawMaterialClass> GetAllClasses(bool containRoot)
        {
            using(var db = new Entities())
            {
                if (containRoot)
                {
                    var classes = new List<RawMaterialClass>();
                    var root = new RawMaterialClass();
                    root.Name = "- 根分类 -";
                    root.ParentId = null;
                    classes.Add(root);
                    var temp = db.RawMaterialClassSet.Select(i => i).ToList();
                    classes = classes.Concat(temp).ToList();
                    return classes;
                }
                else
                    return db.RawMaterialClassSet.Select(i => i).ToList();
            }
        }

        public static List<RawMaterialClass> GetClassesExcept(int index)
        {
            using (var db = new Entities())
            {
                var classes = new List<RawMaterialClass>();
                var root = new RawMaterialClass();
                root.Name = "- 根分类 -";
                root.ParentId = null;
                classes.Add(root);
                var temp =db.RawMaterialClassSet.Where(i => i.Id != index).Select(i => i).ToList();
                classes = classes.Concat(temp).ToList();
                return classes;
            }
        }

        public static List<RawMaterialClass> GetClassesExceptSub(int index)
        {
            var list = GetAllClasses(true);
            var sub = GetSubClassIndexs(index);
            var classes = new List<RawMaterialClass>();
            foreach (var i in list)
            {
                if(sub.FindIndex(x => x == i.Id) == -1)
                {
                    classes.Add(i);
                }
            }
            return classes;
        }

        public static RawMaterialClass GetById(int index)
        {
            using (var db = new Entities())
            {
                return db.RawMaterialClassSet.First(i => i.Id == index);
            }
        }

        //获取种类A及其所有子类的索引
        public static List<int> GetSubClassIndexs(int index)
        {
            using(var db = new Entities())
            {
                var dSubIndexs = db.RawMaterialClassSet.Where(i => i.ParentId == index).Select(i => i.Id).ToList();
                var sumIndexs = new List<int>(dSubIndexs);
                sumIndexs.Add(index);

                foreach (var subIndex in dSubIndexs)
                {
                    var tempList = GetSubClassIndexs(subIndex);
                    sumIndexs = sumIndexs.Union(tempList).ToList();
                }
                return sumIndexs;
            }
        }

        public static List<RawMaterial> GetSubClassMaterials(int index)
        {
            var classList = GetSubClassIndexs(index);
            using (var db = new Entities())
            {
                var sumList = new List<RawMaterial>();
                foreach (int id in classList)
                {
                    var temp = db.RawMaterialSet.Where(i => i.ClassId == id).Select(i => i).ToList();
                    sumList = sumList.Union(temp).ToList();
                }
                return sumList;
            }
        }

        public static void DeleteSubClass(int index)
        {
            //TODO: 实现级联删除
            using (var db = new Entities())
            {
                var temp = db.RawMaterialClassSet.First(i => i.Id == index);
                db.RawMaterialClassSet.Remove(temp);
                db.SaveChanges();
            }
        }
    }
}
