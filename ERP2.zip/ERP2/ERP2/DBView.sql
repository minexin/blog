use erp;

/* 产品配方 */
/*
drop view productformulaview;
create view productformulaview as
select rawmaterialset.Id, rawmaterialset.Name, Quantity, Unit ,ProductId, rawmaterialset.Specification
from productformulaitemset join rawmaterialset on productformulaitemset.RawMaterialId = rawmaterialset.Id;

select * from productformulaview;
select * from rawmaterialset where Id= 4;
*/

/* 订单项目 */
/*
create view orderitemview as
select productset.Id, productset.Code, productset.Name, orderitemset.Quantity, orderitemset.OrderId
from productset join orderitemset on orderitemset.ProductId = productset.Id;
*/