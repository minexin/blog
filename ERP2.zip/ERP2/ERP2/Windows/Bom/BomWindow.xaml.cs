﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP2.Windows.Bom
{
    /// <summary>
    /// BomWindow.xaml 的交互逻辑
    /// </summary>
    public partial class BomWindow : Window
    {
        public BomWindow()
        {
            InitializeComponent();
            txtStatus.Text = "欢迎使用ERP系统, 管理员 admin";
            RefreshTvMaterial();
            RefreshTvProduct();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.MainWindow = Global.MainWindow;
            Close();
            Global.MainWindow.Visibility = Visibility.Visible;
        }

        #region Tab 原料管理
        private void RefreshTvMaterial()
        {
            tvMaterial.Items.Clear();
            using (var db = new Entities())
            {
                var results = db.RawMaterialClassSet.Where(i => i.ParentId == null).Select(i => i);
                foreach (var i in results)
                    tvMaterial.Items.Add(i.GetTreeViewItem());

                dgMaterial.ItemsSource = db.RawMaterialSet.Select(i => i).ToList();
            }
        }

        private void RefreshDgMaterial()
        {
            if(tvMaterial.SelectedItem == null)
            {
                using (var db = new Entities())
                {
                    dgMaterial.ItemsSource = db.RawMaterialSet.Select(i => i).ToList();
                }
            }
            else
            {
                int id = (int)((TreeViewItem)tvMaterial.SelectedItem).DataContext;
                dgMaterial.ItemsSource = RawMaterialClass.GetSubClassMaterials(id);
            }
        }

        private void SelectMaterialClass(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            btnEditMaterialClass.IsEnabled = true;
            btnDeleteMaterialClass.IsEnabled = true;
            if (tvMaterial.SelectedItem == null) return;
            int id = (int)((TreeViewItem)tvMaterial.SelectedItem).DataContext;
            dgMaterial.ItemsSource = RawMaterialClass.GetSubClassMaterials(id);
        }

        //显示所有零件
        private void ShowAllMaterials(object sender, RoutedEventArgs e)
        {
            using (var db = new Entities())
            {
                dgMaterial.ItemsSource = db.RawMaterialSet.Select(i => i).ToList();
            }
        }

        //新建零件种类
        private void NewMaterialClass(object sender, RoutedEventArgs e)
        {
            var results = RawMaterialClass.GetAllClasses(true);
            int? index;
            if (tvMaterial.SelectedItem == null)
                index = null;
            else
                index = (int)((TreeViewItem)tvMaterial.SelectedItem).DataContext;
            var nWin = new NewMaterialClass(results, index);
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                RefreshTvMaterial();
            }
        }

        //修改零件种类
        private void EditMaterialClass(object sender, RoutedEventArgs e)
        {
            int index = (int)((TreeViewItem)tvMaterial.SelectedItem).DataContext;
            var tempClass = RawMaterialClass.GetById(index);
            var nWin = new EditMaterialClass(index);
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                RefreshTvMaterial();
            }
        }

        //删除零件种类
        private void DeleteMaterialClass(object sender, RoutedEventArgs e)
        {
            int index = (int)((TreeViewItem)tvMaterial.SelectedItem).DataContext;
            var nWin = new DeleteMaterialClass(index);
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                RefreshTvMaterial();
            }
        }

        //新建零件
        private void NewMaterial(object sender, RoutedEventArgs e)
        {
            var classes = RawMaterialClass.GetAllClasses(false);
            int? index;
            if (tvMaterial.SelectedItem == null)
                index = null;
            else
                index = (int)((TreeViewItem)tvMaterial.SelectedItem).DataContext;
            var nWin = new NewMaterial(classes, index);
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                RefreshDgMaterial();
            }
        }

        //修改零件
        private void EditMaterial(object sender, RoutedEventArgs e)
        {
            var classes = RawMaterialClass.GetAllClasses(false);
            var temp = dgMaterial.SelectedItem as RawMaterial;
            var nWin = new EditMaterial(classes, temp);
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                RefreshDgMaterial();
            }
        }

        //停用\启用零件
        private void DeleteMaterial(object sender, RoutedEventArgs e)
        {
            var temp = dgMaterial.SelectedItem as RawMaterial;
            using (var db = new Entities())
            {
                var material = db.RawMaterialSet.First(i => i.Id == temp.Id);
                material.Status = !material.Status;
                db.SaveChanges();
                temp.Status = material.Status;
                dgMaterial.Items.Refresh();
            }
        }

        private void EnableMaterialButton(object sender, SelectionChangedEventArgs e)
        {
            if (dgMaterial.SelectedItem == null)
            {
                btnEditMaterial.IsEnabled = false;
                btnDeleteMaterial.IsEnabled = false;
            }
            else
            {
                btnEditMaterial.IsEnabled = true;
                btnDeleteMaterial.IsEnabled = true;
            }
        }

        #endregion

        private void RefreshTvProduct()
        {
            tvProduct.Items.Clear();
            using (var db = new Entities())
            {
                var results = db.ProductClassSet.Where(i => i.ParentId == null).Select(i => i);
                foreach (var i in results)
                    tvProduct.Items.Add(i.GetTreeViewItem());

                dgProduct.ItemsSource = db.ProductSet.Select(i => i).ToList();
            }
        }

        private void RefreshDgProduct()
        {
            if (tvProduct.SelectedItem == null)
            {
                using (var db = new Entities())
                {
                    dgProduct.ItemsSource = db.ProductSet.Select(i => i).ToList();
                }
            }
            else
            {
                int id = (int)((TreeViewItem)tvProduct.SelectedItem).DataContext;
                dgProduct.ItemsSource = ProductClass.GetSubClassProducts(id);
            }
        }

        private void RefreshDgFormula() {
            if (dgProduct.SelectedItem == null)
            {
                dgFormula.ItemsSource = null;
            }
            else
            {
                var temp = dgProduct.SelectedItem as Product;
                dgFormula.ItemsSource = ProductFormulaView.GetByProductId(temp.Id);
            }
        }

        private void ShowAllProducts(object sender, RoutedEventArgs e)
        {
            using (var db = new Entities())
            {
                dgProduct.ItemsSource = db.ProductSet.Select(i => i).ToList();
            }
        }

        private void NewProductClass(object sender, RoutedEventArgs e)
        {
            var results = ProductClass.GetAllClasses(true);
            var index = Utils.GetTreeViewSelectedValue(tvProduct);
            var nWin = new NewProductClass(results, index);
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                RefreshTvProduct();
            }
        }

        private void EditProductClass(object sender, RoutedEventArgs e)
        {
            int index = (int)((TreeViewItem)tvProduct.SelectedItem).DataContext;
            var tempClass = ProductClass.GetById(index);
            var nWin = new EditProductClass(ProductClass.GetClassesExcept(index), index);
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                RefreshTvProduct();
            }
        }

        private void DeleteProductClass(object sender, RoutedEventArgs e)
        {
            //TODO: 实现产品类的删除
            var nWin = new DeleteProductClass();
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                RefreshTvProduct();
            }
        }

        //新建产品
        private void NewProduct(object sender, RoutedEventArgs e)
        {
            var index = Utils.GetTreeViewSelectedValue(tvProduct);
            var nWin = new NewProduct(index);
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                RefreshDgProduct();
            }

        }

        private void EditProduct(object sender, RoutedEventArgs e)
        {
            var product = dgProduct.SelectedItem as Product;
            var nWin = new NewProduct(product);
            var rtn = nWin.ShowDialog();
            if (rtn == true)
            {
                RefreshDgProduct();
            }
        }

        private void DeleteProduct(object sender, RoutedEventArgs e)
        {
            var temp = dgProduct.SelectedItem as Product;
            using (var db = new Entities())
            {
                var product = db.ProductSet.First(i => i.Id == temp.Id);
                product.Status = !product.Status;
                db.SaveChanges();
                temp.Status = product.Status;
                dgProduct.Items.Refresh();
            }
        }

        private void OnDgProductSelectedChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            if (dgProduct.SelectedItem == null)
            {
                btnEditProduct.IsEnabled = false;
                btnDeleteProduct.IsEnabled = false;
            }
            else
            {
                btnEditProduct.IsEnabled = true;
                btnDeleteProduct.IsEnabled = true;
            }
            RefreshDgFormula();
        }

        private void SelectProductClass(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            btnEditProductClass.IsEnabled = true;
            btnDeleteProductClass.IsEnabled = true;
            if (tvProduct.SelectedItem == null) return;
            int id = (int)((TreeViewItem)tvProduct.SelectedItem).DataContext;
            dgProduct.ItemsSource = ProductClass.GetSubClassProducts(id);
        }


    }
}
