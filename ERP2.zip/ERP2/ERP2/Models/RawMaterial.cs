﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP2
{
    public partial class RawMaterial
    {
        public static RawMaterial GetById(int index)
        {
            using(var db = new Entities())
            {
                return db.RawMaterialSet.First(i => i.Id == index);
            }
        }
    }
}
