﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace ERP2
{
    public class Utils
    {
        public static int? GetTreeViewSelectedValue(TreeView tv) {
            int? index;
            if (tv.SelectedItem == null)
                index = null;
            else
                index = (int)((TreeViewItem)tv.SelectedItem).DataContext;
            return index;
        }
    }
}
