﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP2
{
    public class OrderItemView
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public int Quantity { get; set; }
        public string Name { get; set; }
        public int OrderId { get; set; }

        public static List<OrderItemView> GetByOrderId(int index)
        {
            using (var db = new Entities())
            {
                string sql = string.Format("select * from orderitemview where OrderId={0}", index);
                return db.Database.SqlQuery<OrderItemView>(sql).ToList();
            }
        }
    }
}
