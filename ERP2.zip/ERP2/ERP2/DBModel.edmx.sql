










































-- -----------------------------------------------------------
-- Entity Designer DDL Script for MySQL Server 4.1 and higher
-- -----------------------------------------------------------
-- Date Created: 04/29/2018 12:26:57

-- Generated from EDMX file: E:\code\csharp\ERP2\ERP2\DBModel.edmx
-- Target version: 3.0.0.0

-- --------------------------------------------------



-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- NOTE: if the constraint does not exist, an ignorable error will be reported.
-- --------------------------------------------------


--    ALTER TABLE `UserSet` DROP CONSTRAINT `FK_UserUserGroup`;

--    ALTER TABLE `ProductFormulaItemSet` DROP CONSTRAINT `FK_FormulaContent`;

--    ALTER TABLE `ProductSet` DROP CONSTRAINT `FK_ProductBelongToClass`;

--    ALTER TABLE `RawMaterialClassSet` DROP CONSTRAINT `FK_RawMaterialClassParent`;

--    ALTER TABLE `RawMaterialSet` DROP CONSTRAINT `FK_RawMaterialBelongToClass`;

--    ALTER TABLE `OrderItemSet` DROP CONSTRAINT `FK_OrderContent`;

--    ALTER TABLE `MaterialListSet` DROP CONSTRAINT `FK_MaterialListBelongToOrder`;

--    ALTER TABLE `MaterialListItemSet` DROP CONSTRAINT `FK_MaterialListContent`;

--    ALTER TABLE `LogSet` DROP CONSTRAINT `FK_LogUser`;

--    ALTER TABLE `MaterialSupplySet` DROP CONSTRAINT `FK_SupplierMaterialSupply`;

--    ALTER TABLE `MaterialSupplySet` DROP CONSTRAINT `FK_RawMaterialMaterialSupply`;

--    ALTER TABLE `ProductClassSet` DROP CONSTRAINT `FK_ProductClassProductClass`;

--    ALTER TABLE `ProductFormulaItemSet` DROP CONSTRAINT `FK_RawMaterialProductFormulaItem`;

--    ALTER TABLE `StorageRecordSet` DROP CONSTRAINT `FK_StorageRecordUser`;

--    ALTER TABLE `OutboundRecordSet` DROP CONSTRAINT `FK_OutboundRecordUser`;

--    ALTER TABLE `InStockSet` DROP CONSTRAINT `FK_InStockProduct`;

--    ALTER TABLE `InStockSet` DROP CONSTRAINT `FK_InStockRawMaterial`;

--    ALTER TABLE `StorageRecordItemSet` DROP CONSTRAINT `FK_WarehouseRecordsProduct`;

--    ALTER TABLE `StorageRecordItemSet` DROP CONSTRAINT `FK_WarehouseRecordsRawMaterial`;

--    ALTER TABLE `OutboundRecordItemSet` DROP CONSTRAINT `FK_OutboundRecordItemProduct`;

--    ALTER TABLE `OutboundRecordItemSet` DROP CONSTRAINT `FK_OutboundRecordItemRawMaterial`;

--    ALTER TABLE `OutboundRecordItemSet` DROP CONSTRAINT `FK_OutboundRecordItemOutboundRecord`;

--    ALTER TABLE `StorageRecordItemSet` DROP CONSTRAINT `FK_StorageRecordStorageRecordItem`;

--    ALTER TABLE `OrderItemSet` DROP CONSTRAINT `FK_OrderItemProduct`;

--    ALTER TABLE `MaterialListItemSet` DROP CONSTRAINT `FK_MaterialListItemRawMaterial`;


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------
SET foreign_key_checks = 0;

    DROP TABLE IF EXISTS `UserSet`;

    DROP TABLE IF EXISTS `UserGroupSet`;

    DROP TABLE IF EXISTS `ProductSet`;

    DROP TABLE IF EXISTS `ProductFormulaItemSet`;

    DROP TABLE IF EXISTS `RawMaterialSet`;

    DROP TABLE IF EXISTS `ProductClassSet`;

    DROP TABLE IF EXISTS `RawMaterialClassSet`;

    DROP TABLE IF EXISTS `OrderSet`;

    DROP TABLE IF EXISTS `OrderItemSet`;

    DROP TABLE IF EXISTS `MaterialListSet`;

    DROP TABLE IF EXISTS `MaterialListItemSet`;

    DROP TABLE IF EXISTS `InStockSet`;

    DROP TABLE IF EXISTS `LogSet`;

    DROP TABLE IF EXISTS `SupplierSet`;

    DROP TABLE IF EXISTS `MaterialSupplySet`;

    DROP TABLE IF EXISTS `StorageRecordSet`;

    DROP TABLE IF EXISTS `OutboundRecordSet`;

    DROP TABLE IF EXISTS `StorageRecordItemSet`;

    DROP TABLE IF EXISTS `OutboundRecordItemSet`;

SET foreign_key_checks = 1;

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------


CREATE TABLE `UserSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`JobNumber` longtext NOT NULL, 
	`Name` longtext NOT NULL, 
	`Password` longtext NOT NULL, 
	`ClassId` int NOT NULL);

ALTER TABLE `UserSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `UserGroupSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`Name` longtext NOT NULL, 
	`Authority` int NOT NULL);

ALTER TABLE `UserGroupSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `ProductSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`Code` longtext NOT NULL, 
	`Name` longtext NOT NULL, 
	`Price` double NOT NULL, 
	`ProductModel` longtext NOT NULL, 
	`Inventor` longtext, 
	`PatentNo` longtext, 
	`AddTime` datetime NOT NULL, 
	`Description` longtext, 
	`ClassId` int NOT NULL, 
	`Status` bool NOT NULL);

ALTER TABLE `ProductSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `ProductFormulaItemSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`RawMaterialId` int NOT NULL, 
	`Quantity` int NOT NULL, 
	`ProductId` int NOT NULL);

ALTER TABLE `ProductFormulaItemSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `RawMaterialSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`Name` longtext NOT NULL, 
	`Specification` longtext NOT NULL, 
	`Unit` longtext NOT NULL, 
	`ClassId` int NOT NULL, 
	`Status` bool NOT NULL);

ALTER TABLE `RawMaterialSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `ProductClassSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`Name` longtext NOT NULL, 
	`ParentId` int);

ALTER TABLE `ProductClassSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `RawMaterialClassSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`Name` longtext NOT NULL, 
	`ParentId` int);

ALTER TABLE `RawMaterialClassSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `OrderSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`Status` longtext NOT NULL, 
	`OrderNo` longtext NOT NULL, 
	`OrderTime` datetime NOT NULL, 
	`DueTime` datetime NOT NULL, 
	`CompleteTIme` datetime, 
	`Priority` bool NOT NULL, 
	`BuyerCo` longtext NOT NULL, 
	`BuyerLeader` longtext NOT NULL, 
	`BuyerTel` longtext NOT NULL, 
	`Description` longtext NOT NULL, 
	`MaterialStatus` bool NOT NULL);

ALTER TABLE `OrderSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `OrderItemSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`OrderId` int NOT NULL, 
	`Quantity` int NOT NULL, 
	`ProductId` int NOT NULL);

ALTER TABLE `OrderItemSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `MaterialListSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`OrderId` int NOT NULL, 
	`Time` datetime NOT NULL);

ALTER TABLE `MaterialListSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `MaterialListItemSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`MaterialListId` int NOT NULL, 
	`RawMaterialId` int NOT NULL);

ALTER TABLE `MaterialListItemSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `InStockSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`IsProduct` bool NOT NULL, 
	`Quantity` int NOT NULL, 
	`ProductId` int, 
	`RawMaterialId` int);

ALTER TABLE `InStockSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `LogSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`Time` datetime NOT NULL, 
	`UserId` int NOT NULL, 
	`Operation` longtext NOT NULL, 
	`Data` longtext NOT NULL);

ALTER TABLE `LogSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `SupplierSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`Company` longtext NOT NULL, 
	`Principal` longtext NOT NULL, 
	`Phone` longtext NOT NULL, 
	`Priority` longtext NOT NULL, 
	`Description` longtext NOT NULL);

ALTER TABLE `SupplierSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `MaterialSupplySet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`SupplierId` int NOT NULL, 
	`Batch` longtext NOT NULL, 
	`Price` int NOT NULL, 
	`RawMaterialId` int NOT NULL);

ALTER TABLE `MaterialSupplySet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `StorageRecordSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`UserId` int NOT NULL);

ALTER TABLE `StorageRecordSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `OutboundRecordSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`UserId` int NOT NULL);

ALTER TABLE `OutboundRecordSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `StorageRecordItemSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`IsProduct` bool NOT NULL, 
	`ProductId` int, 
	`RawMaterialId` int, 
	`StorageRecordId` int NOT NULL);

ALTER TABLE `StorageRecordItemSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `OutboundRecordItemSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`IsProduct` longtext NOT NULL, 
	`ProductId` int, 
	`RawMaterialId` int, 
	`OutboundRecordId` int NOT NULL);

ALTER TABLE `OutboundRecordItemSet` ADD PRIMARY KEY (`Id`);





CREATE TABLE `InStockItemSet`(
	`Id` int NOT NULL AUTO_INCREMENT UNIQUE, 
	`Inventory` longtext NOT NULL, 
	`BatchNo` longtext NOT NULL, 
	`IncomingTime` datetime NOT NULL, 
	`Quantity` int NOT NULL, 
	`GoodsAllocation` longtext NOT NULL, 
	`Status` longtext NOT NULL, 
	`Price` longtext NOT NULL, 
	`InStockId` int NOT NULL);

ALTER TABLE `InStockItemSet` ADD PRIMARY KEY (`Id`);







-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------


-- Creating foreign key on `ClassId` in table 'UserSet'

ALTER TABLE `UserSet`
ADD CONSTRAINT `FK_UserUserGroup`
    FOREIGN KEY (`ClassId`)
    REFERENCES `UserGroupSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_UserUserGroup'

CREATE INDEX `IX_FK_UserUserGroup`
    ON `UserSet`
    (`ClassId`);



-- Creating foreign key on `ProductId` in table 'ProductFormulaItemSet'

ALTER TABLE `ProductFormulaItemSet`
ADD CONSTRAINT `FK_FormulaContent`
    FOREIGN KEY (`ProductId`)
    REFERENCES `ProductSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_FormulaContent'

CREATE INDEX `IX_FK_FormulaContent`
    ON `ProductFormulaItemSet`
    (`ProductId`);



-- Creating foreign key on `ClassId` in table 'ProductSet'

ALTER TABLE `ProductSet`
ADD CONSTRAINT `FK_ProductBelongToClass`
    FOREIGN KEY (`ClassId`)
    REFERENCES `ProductClassSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_ProductBelongToClass'

CREATE INDEX `IX_FK_ProductBelongToClass`
    ON `ProductSet`
    (`ClassId`);



-- Creating foreign key on `ParentId` in table 'RawMaterialClassSet'

ALTER TABLE `RawMaterialClassSet`
ADD CONSTRAINT `FK_RawMaterialClassParent`
    FOREIGN KEY (`ParentId`)
    REFERENCES `RawMaterialClassSet`
        (`Id`)
    ON DELETE CASCADE ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_RawMaterialClassParent'

CREATE INDEX `IX_FK_RawMaterialClassParent`
    ON `RawMaterialClassSet`
    (`ParentId`);



-- Creating foreign key on `ClassId` in table 'RawMaterialSet'

ALTER TABLE `RawMaterialSet`
ADD CONSTRAINT `FK_RawMaterialBelongToClass`
    FOREIGN KEY (`ClassId`)
    REFERENCES `RawMaterialClassSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_RawMaterialBelongToClass'

CREATE INDEX `IX_FK_RawMaterialBelongToClass`
    ON `RawMaterialSet`
    (`ClassId`);



-- Creating foreign key on `OrderId` in table 'OrderItemSet'

ALTER TABLE `OrderItemSet`
ADD CONSTRAINT `FK_OrderContent`
    FOREIGN KEY (`OrderId`)
    REFERENCES `OrderSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_OrderContent'

CREATE INDEX `IX_FK_OrderContent`
    ON `OrderItemSet`
    (`OrderId`);



-- Creating foreign key on `OrderId` in table 'MaterialListSet'

ALTER TABLE `MaterialListSet`
ADD CONSTRAINT `FK_MaterialListBelongToOrder`
    FOREIGN KEY (`OrderId`)
    REFERENCES `OrderSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_MaterialListBelongToOrder'

CREATE INDEX `IX_FK_MaterialListBelongToOrder`
    ON `MaterialListSet`
    (`OrderId`);



-- Creating foreign key on `MaterialListId` in table 'MaterialListItemSet'

ALTER TABLE `MaterialListItemSet`
ADD CONSTRAINT `FK_MaterialListContent`
    FOREIGN KEY (`MaterialListId`)
    REFERENCES `MaterialListSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_MaterialListContent'

CREATE INDEX `IX_FK_MaterialListContent`
    ON `MaterialListItemSet`
    (`MaterialListId`);



-- Creating foreign key on `UserId` in table 'LogSet'

ALTER TABLE `LogSet`
ADD CONSTRAINT `FK_LogUser`
    FOREIGN KEY (`UserId`)
    REFERENCES `UserSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_LogUser'

CREATE INDEX `IX_FK_LogUser`
    ON `LogSet`
    (`UserId`);



-- Creating foreign key on `SupplierId` in table 'MaterialSupplySet'

ALTER TABLE `MaterialSupplySet`
ADD CONSTRAINT `FK_SupplierMaterialSupply`
    FOREIGN KEY (`SupplierId`)
    REFERENCES `SupplierSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_SupplierMaterialSupply'

CREATE INDEX `IX_FK_SupplierMaterialSupply`
    ON `MaterialSupplySet`
    (`SupplierId`);



-- Creating foreign key on `RawMaterialId` in table 'MaterialSupplySet'

ALTER TABLE `MaterialSupplySet`
ADD CONSTRAINT `FK_RawMaterialMaterialSupply`
    FOREIGN KEY (`RawMaterialId`)
    REFERENCES `RawMaterialSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_RawMaterialMaterialSupply'

CREATE INDEX `IX_FK_RawMaterialMaterialSupply`
    ON `MaterialSupplySet`
    (`RawMaterialId`);



-- Creating foreign key on `ParentId` in table 'ProductClassSet'

ALTER TABLE `ProductClassSet`
ADD CONSTRAINT `FK_ProductClassProductClass`
    FOREIGN KEY (`ParentId`)
    REFERENCES `ProductClassSet`
        (`Id`)
    ON DELETE CASCADE ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_ProductClassProductClass'

CREATE INDEX `IX_FK_ProductClassProductClass`
    ON `ProductClassSet`
    (`ParentId`);



-- Creating foreign key on `RawMaterialId` in table 'ProductFormulaItemSet'

ALTER TABLE `ProductFormulaItemSet`
ADD CONSTRAINT `FK_RawMaterialProductFormulaItem`
    FOREIGN KEY (`RawMaterialId`)
    REFERENCES `RawMaterialSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_RawMaterialProductFormulaItem'

CREATE INDEX `IX_FK_RawMaterialProductFormulaItem`
    ON `ProductFormulaItemSet`
    (`RawMaterialId`);



-- Creating foreign key on `UserId` in table 'StorageRecordSet'

ALTER TABLE `StorageRecordSet`
ADD CONSTRAINT `FK_StorageRecordUser`
    FOREIGN KEY (`UserId`)
    REFERENCES `UserSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_StorageRecordUser'

CREATE INDEX `IX_FK_StorageRecordUser`
    ON `StorageRecordSet`
    (`UserId`);



-- Creating foreign key on `UserId` in table 'OutboundRecordSet'

ALTER TABLE `OutboundRecordSet`
ADD CONSTRAINT `FK_OutboundRecordUser`
    FOREIGN KEY (`UserId`)
    REFERENCES `UserSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_OutboundRecordUser'

CREATE INDEX `IX_FK_OutboundRecordUser`
    ON `OutboundRecordSet`
    (`UserId`);



-- Creating foreign key on `ProductId` in table 'InStockSet'

ALTER TABLE `InStockSet`
ADD CONSTRAINT `FK_InStockProduct`
    FOREIGN KEY (`ProductId`)
    REFERENCES `ProductSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_InStockProduct'

CREATE INDEX `IX_FK_InStockProduct`
    ON `InStockSet`
    (`ProductId`);



-- Creating foreign key on `RawMaterialId` in table 'InStockSet'

ALTER TABLE `InStockSet`
ADD CONSTRAINT `FK_InStockRawMaterial`
    FOREIGN KEY (`RawMaterialId`)
    REFERENCES `RawMaterialSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_InStockRawMaterial'

CREATE INDEX `IX_FK_InStockRawMaterial`
    ON `InStockSet`
    (`RawMaterialId`);



-- Creating foreign key on `ProductId` in table 'StorageRecordItemSet'

ALTER TABLE `StorageRecordItemSet`
ADD CONSTRAINT `FK_WarehouseRecordsProduct`
    FOREIGN KEY (`ProductId`)
    REFERENCES `ProductSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_WarehouseRecordsProduct'

CREATE INDEX `IX_FK_WarehouseRecordsProduct`
    ON `StorageRecordItemSet`
    (`ProductId`);



-- Creating foreign key on `RawMaterialId` in table 'StorageRecordItemSet'

ALTER TABLE `StorageRecordItemSet`
ADD CONSTRAINT `FK_WarehouseRecordsRawMaterial`
    FOREIGN KEY (`RawMaterialId`)
    REFERENCES `RawMaterialSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_WarehouseRecordsRawMaterial'

CREATE INDEX `IX_FK_WarehouseRecordsRawMaterial`
    ON `StorageRecordItemSet`
    (`RawMaterialId`);



-- Creating foreign key on `ProductId` in table 'OutboundRecordItemSet'

ALTER TABLE `OutboundRecordItemSet`
ADD CONSTRAINT `FK_OutboundRecordItemProduct`
    FOREIGN KEY (`ProductId`)
    REFERENCES `ProductSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_OutboundRecordItemProduct'

CREATE INDEX `IX_FK_OutboundRecordItemProduct`
    ON `OutboundRecordItemSet`
    (`ProductId`);



-- Creating foreign key on `RawMaterialId` in table 'OutboundRecordItemSet'

ALTER TABLE `OutboundRecordItemSet`
ADD CONSTRAINT `FK_OutboundRecordItemRawMaterial`
    FOREIGN KEY (`RawMaterialId`)
    REFERENCES `RawMaterialSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_OutboundRecordItemRawMaterial'

CREATE INDEX `IX_FK_OutboundRecordItemRawMaterial`
    ON `OutboundRecordItemSet`
    (`RawMaterialId`);



-- Creating foreign key on `OutboundRecordId` in table 'OutboundRecordItemSet'

ALTER TABLE `OutboundRecordItemSet`
ADD CONSTRAINT `FK_OutboundRecordItemOutboundRecord`
    FOREIGN KEY (`OutboundRecordId`)
    REFERENCES `OutboundRecordSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_OutboundRecordItemOutboundRecord'

CREATE INDEX `IX_FK_OutboundRecordItemOutboundRecord`
    ON `OutboundRecordItemSet`
    (`OutboundRecordId`);



-- Creating foreign key on `StorageRecordId` in table 'StorageRecordItemSet'

ALTER TABLE `StorageRecordItemSet`
ADD CONSTRAINT `FK_StorageRecordStorageRecordItem`
    FOREIGN KEY (`StorageRecordId`)
    REFERENCES `StorageRecordSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_StorageRecordStorageRecordItem'

CREATE INDEX `IX_FK_StorageRecordStorageRecordItem`
    ON `StorageRecordItemSet`
    (`StorageRecordId`);



-- Creating foreign key on `ProductId` in table 'OrderItemSet'

ALTER TABLE `OrderItemSet`
ADD CONSTRAINT `FK_OrderItemProduct`
    FOREIGN KEY (`ProductId`)
    REFERENCES `ProductSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_OrderItemProduct'

CREATE INDEX `IX_FK_OrderItemProduct`
    ON `OrderItemSet`
    (`ProductId`);



-- Creating foreign key on `RawMaterialId` in table 'MaterialListItemSet'

ALTER TABLE `MaterialListItemSet`
ADD CONSTRAINT `FK_MaterialListItemRawMaterial`
    FOREIGN KEY (`RawMaterialId`)
    REFERENCES `RawMaterialSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_MaterialListItemRawMaterial'

CREATE INDEX `IX_FK_MaterialListItemRawMaterial`
    ON `MaterialListItemSet`
    (`RawMaterialId`);



-- Creating foreign key on `InStockId` in table 'InStockItemSet'

ALTER TABLE `InStockItemSet`
ADD CONSTRAINT `FK_InStockItemInStock`
    FOREIGN KEY (`InStockId`)
    REFERENCES `InStockSet`
        (`Id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION;


-- Creating non-clustered index for FOREIGN KEY 'FK_InStockItemInStock'

CREATE INDEX `IX_FK_InStockItemInStock`
    ON `InStockItemSet`
    (`InStockId`);



-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------
