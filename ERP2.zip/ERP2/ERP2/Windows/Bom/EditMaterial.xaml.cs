﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP2.Windows.Bom
{
    /// <summary>
    /// EditMaterial.xaml 的交互逻辑
    /// </summary>
    public partial class EditMaterial : Window
    {
        private int index;

        public EditMaterial(List<RawMaterialClass> list, RawMaterial rawMaterial)
        {
            InitializeComponent();
            cbClass.ItemsSource = list;
            cbClass.SelectedValue = rawMaterial.ClassId;
            index = rawMaterial.Id;
            txtName.Text = rawMaterial.Name;
            txtSpecification.Text = rawMaterial.Specification;
            txtUnit.Text = rawMaterial.Unit;
        }

        private void btnOK(object sender, RoutedEventArgs e)
        {
            if (cbClass.SelectedValue == null)
                message.Text = "请选择种类";
            else if (txtName.Text == "")
                message.Text = "请输入零件名";
            else if (txtSpecification.Text == "")
                message.Text = "请输入零件规格";
            else if (txtUnit.Text == "")
                message.Text = "请输入零件计量单位";
            else
                using (var db = new Entities())
                {
                    var temp = db.RawMaterialSet.First(i => i.Id == index);
                    temp.Name = txtName.Text;
                    temp.Specification = txtSpecification.Text;
                    temp.Unit = txtUnit.Text;
                    temp.ClassId = (int)cbClass.SelectedValue;
                    db.SaveChanges();
                    DialogResult = true;
                    Close();
                }
        }
    }
}
