﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP2.Windows
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            InitButtonText();
        }

        void InitButtonText()
        {
            btnBOM.Content = "-BOM管理-\n\n产品配方管理\n物料信息管理";
            btnOrder.Content = "-订单管理-\n\n新订单\n订单管理";
            btnProduct.Content = "-生产管理-\n\n物料确认\n领料单管理";
            btnStorage.Content = "-仓库管理-\n\n出入库管理\n库存统计\n成本管理";
            btnPurchase.Content = "-采购辅助-\n\n缺料浏览\n物料报价管理\n供货商管理";
            btnUser.Content = "-用户管理-\n\n修改密码\n用户管理\n用户组管理";
        }

        void OpenBomWindow(object sender, RoutedEventArgs e)
        {
            Global.MainWindow = this;
            var nWin = new Bom.BomWindow();
            Application.Current.MainWindow = nWin;
            Visibility = Visibility.Hidden;
            nWin.Show();
        }

        private void OpenOrderWindow(object sender, RoutedEventArgs e)
        {
            Global.MainWindow = this;
            var nWin = new Order.OrderWindow();
            Application.Current.MainWindow = nWin;
            Visibility = Visibility.Hidden;
            nWin.Show();
        }

        private void OpenProduceWindow(object sender, RoutedEventArgs e)
        {
            Global.MainWindow = this;
            var nWin = new Produce.ProduceWindow();
            Application.Current.MainWindow = nWin;
            Visibility = Visibility.Hidden;
            nWin.Show();
        }

        private void OpenInventoryWindow(object sender, RoutedEventArgs e)
        {
            Global.MainWindow = this;
            var nWin = new Inventory.InventoryWindow();
            Application.Current.MainWindow = nWin;
            Visibility = Visibility.Hidden;
            nWin.Show();
        }

        private void OpenPurchaseWindow(object sender, RoutedEventArgs e)
        {
            Global.MainWindow = this;
            var nWin = new Purchase.PurchaseWindow();
            Application.Current.MainWindow = nWin;
            Visibility = Visibility.Hidden;
            nWin.Show();
        }

        private void OpenUserWindow(object sender, RoutedEventArgs e)
        {
            Global.MainWindow = this;
            var nWin = new User.UserWindow();
            Application.Current.MainWindow = nWin;
            Visibility = Visibility.Hidden;
            nWin.Show();
        }
    }
}
