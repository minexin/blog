﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ERP2.Windows
{
    /// <summary>
    /// LoginWindow.xaml 的交互逻辑
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void Login(object sender, RoutedEventArgs e)
        {
            using(var db = new Entities())
            {
                var result = db.UserSet.FirstOrDefault(i => i.Name == txtName.Text);
                if (result == null)
                {
                    MessageBox.Show("用户不存在!");
                }
                else if(result.Password != pwbPassword.Password)
                {
                    MessageBox.Show("密码错误!");
                }
                else
                {
                    Global.user = result;                    
                    Global.MainWindow = new MainWindow();
                    Application.Current.MainWindow = Global.MainWindow;
                    Global.MainWindow.Show();
                    Close();
                }
            }
        }
    }
}
